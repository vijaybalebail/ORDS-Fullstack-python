# python3-flask-oracle-idcs

### Repo showing how to authenticate a Python Flask web application with Oracle Identity Cloud Service. 

### Code here is Flask modification of the original Django version shown in the documentation:

https://www.oracle.com/webfolder/technetwork/tutorials/obe/cloud/idcs/idcs_python_sdk_obe/idcs-python-sdk.html



